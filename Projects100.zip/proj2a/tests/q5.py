test = {   'name': 'q5',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> training_accuracy > 0.72\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
