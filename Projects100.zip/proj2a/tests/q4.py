test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> X_train.shape\n(7513, 5)',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.unique(X_train) # X '
                                               'matrix should consist of only '
                                               '0 or 1\n'
                                               'array([0, 1])',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.unique(Y_train) # y '
                                               'vector should consist of only '
                                               '0 or 1\n'
                                               'array([0, 1])',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
