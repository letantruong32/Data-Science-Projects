test = {   'name': 'q1b',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> len(first_ham) > 0 and '
                                               "first_ham[:0] == ''\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(first_spam) > 0 and '
                                               "first_spam[:0] == ''\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
