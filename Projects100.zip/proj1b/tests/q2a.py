test = {   'name': 'q2a',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> max_swing in '
                                               "set(bus['name'])\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
