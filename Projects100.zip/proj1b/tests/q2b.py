test = {   'name': 'q2b',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               "np.isclose(sum(inspections_by_id_and_year['count']), "
                                               '14222,rtol=5)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'set(inspections_by_id_and_year.index.names) '
                                               "== set(['bid', 'year'])\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
