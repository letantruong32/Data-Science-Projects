test = {   'name': 'q2ci',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'isinstance(scores_pairs_by_business, '
                                               'pd.DataFrame)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'scores_pairs_by_business.columns[0] '
                                               "== 'score_pair'\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
