test = {   'name': 'q3e',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> type(q3d_true_or_false) == '
                                               'bool\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
