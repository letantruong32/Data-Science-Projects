test = {   'name': 'q3cii',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(invalid_zip_bus) == '
                                               'pd.DataFrame\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(invalid_zip_bus) == '
                                               '230\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
