test = {   'name': 'q4ciii',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(earliest_date) == '
                                               'pd.Timestamp\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> type(latest_date) == '
                                               'pd.Timestamp\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
