test = {   'name': 'q2cii',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> len(address_counts) == '
                                               '5673\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> address_counts["428 11th '
                                               'St"] == 34\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
