test = {   'name': 'q3a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(zip_counts) == '
                                               'pd.Series\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> zip_counts.shape[0] == 63\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> zip_counts["94103"] == '
                                               '562\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
