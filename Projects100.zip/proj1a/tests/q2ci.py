test = {   'name': 'q2ci',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> len(name_counts) == 5775\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> name_counts["Peet\'s '
                                               'Coffee & Tea"] == 20\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
