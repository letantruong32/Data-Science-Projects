test = {   'name': 'q3d',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'type(missing_zip_address_count) '
                                               '== pd.Series\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'len(missing_zip_address_count) '
                                               '== 135\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               "missing_zip_address_count['3914 "
                                               "Judah St'] == 1\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
