test = {   'name': 'q4cii',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> type(ins['timestamp'][0]) "
                                               '== pd.Timestamp\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
