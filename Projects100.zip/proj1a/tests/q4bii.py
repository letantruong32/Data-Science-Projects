test = {   'name': 'q4bii',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> invalid_bid_count >= 0 \n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
