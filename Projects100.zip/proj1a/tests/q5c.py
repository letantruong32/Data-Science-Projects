test = {   'name': 'q5c',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> type(low_score_violations) '
                                               '== pd.Series\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(low_score_violations) '
                                               '== 50\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> low_score_violations[0] == '
                                               '43\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
