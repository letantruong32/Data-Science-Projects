test = {   'name': 'q4civ',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> 'year' in ins.columns\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
