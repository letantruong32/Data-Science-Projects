test = {   'name': 'q5b',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'twenty_lowest_scoring.shape == '
                                               '(20, 3)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'set(twenty_lowest_scoring.columns) '
                                               "== {'bid', 'median score', "
                                               "'name'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
