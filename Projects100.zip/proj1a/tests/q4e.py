test = {   'name': 'q4e',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'type(ins_missing_score_pivot) '
                                               '== pd.DataFrame\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
