test = {   'name': 'q4biii',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(q4b_is_foreign_key) '
                                               '== bool\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
