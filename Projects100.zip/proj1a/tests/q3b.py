test = {   'name': 'q3b',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> q3b_part1 in '
                                               'set(["Quantitative '
                                               'Continuous", "Quantitative '
                                               'Discrete", \n'
                                               '...                   '
                                               '"Qualitative Ordinal", '
                                               '"Qualitative Nominal"])\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> q3b_part2 in set(["str", '
                                               '"int", "bool", "float"])\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
