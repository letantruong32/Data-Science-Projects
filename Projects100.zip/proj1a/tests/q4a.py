test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'type(is_ins_iid_a_primary_key) '
                                               '== bool or '
                                               'type(is_ins_iid_a_primary_key) '
                                               '== np.bool_\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
