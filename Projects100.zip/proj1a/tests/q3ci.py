test = {   'name': 'q3ci',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> valid_zips.dtype == '
                                               'object \n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> type(valid_zips) == '
                                               'pd.Series\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
