test = {   'name': 'q4bi',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> 'bid' in ins.columns\nTrue",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> ins['bid'].dtype == int\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> len(ins['bid'].unique()) "
                                               '== 6253\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
