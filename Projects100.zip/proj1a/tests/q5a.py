test = {   'name': 'q5a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> "name" in ins_named and '
                                               '"address" in ins_named\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(ins_named) == '
                                               'len(ins)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               "ins_named['date'].equals(ins['date'])\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
