test = {   'name': 'q2d',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> q2d_part1 in set(["One '
                                               'location of a restaurant.", "A '
                                               'chain of restaurants.", "A '
                                               'city block."])\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> q2d_part2 in set(["bid", '
                                               '"bid, name", "bid, name, '
                                               'address"])\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
