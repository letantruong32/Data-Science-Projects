test = {   'name': 'q4di',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'set(ins_pivot_sorted.columns) '
                                               '== {2016, 2017, 2018, 2019, '
                                               "'Total'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(ins_pivot_sorted) == '
                                               '15\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
