test = {   'name': 'q4dii',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'type(year_of_new_construction) '
                                               '== int\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
