test = {   'name': 'q1d',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> set(bus.columns) == '
                                               "{'business id column', "
                                               "'latitude', 'longitude', \n"
                                               '...                      '
                                               "'state', 'address', 'name', "
                                               "'phone_number', \n"
                                               '...                      '
                                               "'postal_code', 'city'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> bus.shape == (6253, 9)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> set(ins.columns) == '
                                               "{'date', 'iid', 'score', "
                                               "'type'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> ins.shape == (26663, 4)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
